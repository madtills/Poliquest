/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.jogomilhao.Telas;

import com.mycompany.jogomilhao.ImagePanel;
import com.mycompany.jogomilhao.Persistencia.PerguntaDAO;
import com.mycompany.jogomilhao.TelaCadastro.Pergunta;
import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Windows
 */
public class TelaPergunta extends javax.swing.JFrame {
    
// --- AQUI É ONDE VOCÊ INSERE O CÓDIGO ---
    private List<Pergunta> listaPerguntas; // Vai armazenar todas as perguntas do banco de dados
    private int perguntaAtual = 0; // Vai controlar qual pergunta está sendo exibida no momento
    // ------------------------------------------
   

    
    
    /**
     * Creates new form TelaPergunta
     */
    public TelaPergunta(String materia) {
        initComponents();
        // --- AQUI É ONDE VOCÊ ADICIONA OS LISTENERS ---
        // Eles conectam os cliques dos botões ao método verificarResposta()
        btnA.addActionListener(e -> verificarResposta('A')); // Usar 'A', 'B', 'C', 'D' maiúsculas
        btnB.addActionListener(e -> verificarResposta('B'));
        btnC.addActionListener(e -> verificarResposta('C'));
        btnD.addActionListener(e -> verificarResposta('D'));
        
        carregarPerguntas(materia); // <<<<< NÃO ESQUECER DISSO
        // ------------------------------------------------
        ImagePanel imagePanel = new
        ImagePanel(getClass().getResource("/imagens/telaJogoPerguntas.png"));
        this.setContentPane(imagePanel);
        this.setLayout(new BorderLayout());
        // Certifique-se de que todos os componentes são adicionados ao painel da imagem
        imagePanel.add(jPanel1);
        // Certifique-se de que a janela está corretamente dimensionada
        this.pack();
    }

    TelaPergunta() {
        
    }
    // AQUI É ONDE VOCÊ INSERE O CÓDIGO DO MÉTODO carregarPerguntas()
    public void carregarPerguntas(String materia) {
        // Reinicia a lista e o contador sempre que for carregar novas perguntas
        this.listaPerguntas = new ArrayList<>();
        this.perguntaAtual = 0;

        // Cria uma instância do seu DAO
        PerguntaDAO dao = new PerguntaDAO();

        // Tenta buscar as perguntas do banco
        try {
            // Chama o método no DAO para buscar perguntas aleatórias por matéria
            listaPerguntas = dao.buscarPerguntasPorMateria(materia, 10);

        } catch (Exception e) {
            // Em caso de erro na comunicação com o banco de dados
            JOptionPane.showMessageDialog(this, "Erro ao carregar perguntas: " + e.getMessage(), "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace(); // Imprime o stack trace para depuração
            this.dispose(); // Fecha a tela ou trata o erro de outra forma
            return; // Sai do método se houver erro
        }


        if (listaPerguntas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nenhuma pergunta encontrada para a matéria: " + materia);
            // Decide o que fazer se não houver perguntas (ex: fechar a tela, voltar ao menu)
            // this.dispose();
        } else {
            // Se encontrou perguntas, mostra a primeira
            mostrarPergunta();
        }
    }
    // ---------------------------------------------------------------
    
// --- AQUI É ONDE VOCÊ INSERE O CÓDIGO DO MÉTODO mostrarPergunta() ---
    private void mostrarPergunta() {
        if (perguntaAtual < listaPerguntas.size()) {
            Pergunta p = listaPerguntas.get(perguntaAtual);
            // Certifique-se de que esses componentes (lblEnunciado, btnA, etc.) existem na sua tela
            // e que os nomes estão corretos (lblEnunciado, btnA, btnB, btnC, btnD).
            lblEnunciado.setText(p.getEnunciado());
            btnA.setText("A) " + p.getAlternativaA());
            btnB.setText("B) " + p.getAlternativaB());
            btnC.setText("C) " + p.getAlternativaC());
            btnD.setText("D) " + p.getAlternativaD());
        } else {
            // Fim das perguntas
            JOptionPane.showMessageDialog(this, "Você Terminou!");
            this.dispose(); // Fecha a janela da tela do jogo
        }
    }
    private void verificarResposta(char letra) {
    Pergunta p = listaPerguntas.get(perguntaAtual);
    if (p.getRespostaCorreta() == letra) {
        JOptionPane.showMessageDialog(this, "✅ Resposta correta!");
    } else {
        JOptionPane.showMessageDialog(this, "❌ Resposta errada! Correta: " + p.getRespostaCorreta());
    }
    perguntaAtual++;
    mostrarPergunta();
}

    // --------------------------------------------------------------------
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblEnunciado = new javax.swing.JLabel();
        btnA = new javax.swing.JButton();
        btnB = new javax.swing.JButton();
        btnC = new javax.swing.JButton();
        btnD = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setOpaque(false);

        lblEnunciado.setBackground(new java.awt.Color(255, 255, 255));
        lblEnunciado.setForeground(new java.awt.Color(0, 0, 0));
        lblEnunciado.setText("jLabel1");
        lblEnunciado.setOpaque(true);

        btnA.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnA.setText("A");
        btnA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAActionPerformed(evt);
            }
        });

        btnB.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnB.setText("B");
        btnB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBActionPerformed(evt);
            }
        });

        btnC.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnC.setText("C");
        btnC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCActionPerformed(evt);
            }
        });

        btnD.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnD.setText("D");
        btnD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnA, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                            .addComponent(btnB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnD, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(lblEnunciado, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(475, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(lblEnunciado, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnA, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnB, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnC, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnD, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(92, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDActionPerformed
        // TODO add your handling code here:
         verificarResposta('D');
    }//GEN-LAST:event_btnDActionPerformed

    private void btnAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAActionPerformed
        // TODO add your handling code here:
         verificarResposta('A');
    }//GEN-LAST:event_btnAActionPerformed

    private void btnCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCActionPerformed
        // TODO add your handling code here:
         verificarResposta('C');
    }//GEN-LAST:event_btnCActionPerformed

    private void btnBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBActionPerformed
        // TODO add your handling code here:
         verificarResposta('B');
    }//GEN-LAST:event_btnBActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnA;
    private javax.swing.JButton btnB;
    private javax.swing.JButton btnC;
    private javax.swing.JButton btnD;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblEnunciado;
    // End of variables declaration//GEN-END:variables

    

}
