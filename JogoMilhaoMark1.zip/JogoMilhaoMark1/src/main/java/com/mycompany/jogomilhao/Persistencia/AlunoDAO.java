package com.mycompany.jogomilhao.Persistencia;

import com.mycompany.jogomilhao.TelaCadastro.Aluno;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AlunoDAO {

    public void cadastrarAluno(Aluno aluno) throws Exception {
        String sql = "INSERT INTO alunos (nome, email, data_nascimento) VALUES (?, ?, ?)";

        try (
            Connection conn = new ConnectionFactory().getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getEmail());
            stmt.setDate(3, aluno.getDataNascimento());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao cadastrar aluno", e);
        }

    }

    // Login de aluno usando email e data de nascimento como senha
    public boolean validarLoginPorData(String email, Date dataNascimento) throws Exception {
        String sql = "SELECT * FROM alunos WHERE email = ? AND data_nascimento = ?";

        try (
            Connection conn = new ConnectionFactory().getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setString(1, email);
            stmt.setDate(2, dataNascimento); // dataNascimento deve ser java.sql.Date

            ResultSet rs = stmt.executeQuery();
            return rs.next(); // true se encontrou um aluno válido

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Pode remover esse se não for usar login por senha comum
    public boolean validarLogin(String email, String senha) {
        throw new UnsupportedOperationException("Esse método não está implementado porque usamos data como senha.");
    }
}
