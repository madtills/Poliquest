
package com.mycompany.jogomilhao.Persistencia;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
    private String host = "poliquest-bd-beatrizdesiqueiraf-fcca.f.aivencloud.com";
    private String port = "16248";
    private String db = "defaultdb";
    private String user = "avnadmin";
    private String password = "AVNS_pXX1DwkHT7cZ8lT_zEH";

    public Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver"); // Carrega o driver
        String url = String.format(
            "jdbc:mysql://%s:%s/%s?sslMode=REQUIRED", 
            host, port, db
        );
        return DriverManager.getConnection(url, user, password);
    }
}
