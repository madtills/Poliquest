package com.mycompany.jogomilhao.Persistencia;

import com.mycompany.jogomilhao.TelaCadastro.Pergunta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PerguntaDAO {

    public List<Pergunta> buscarPerguntasPorMateria(String materia, int limite) throws Exception {
        List<Pergunta> lista = new ArrayList<>();
        String sql = "SELECT * FROM perguntas WHERE materia = ? ORDER BY RAND() LIMIT ?";

        try (
            Connection conn = new ConnectionFactory().getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setString(1, materia);
            stmt.setInt(2, limite);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Pergunta p = new Pergunta(
                    rs.getInt("id"),
                    rs.getString("materia"),
                    rs.getString("enunciado"),
                    rs.getString("alternativa_a"),
                    rs.getString("alternativa_b"),
                    rs.getString("alternativa_c"),
                    rs.getString("alternativa_d"),
                    rs.getString("resposta_correta").charAt(0)
                );
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

    public void adicionarPergunta(Pergunta pergunta) throws Exception {
        String sql = "INSERT INTO perguntas (materia, enunciado, alternativa_a, alternativa_b, alternativa_c, alternativa_d, resposta_correta) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (
            Connection conn = new ConnectionFactory().getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setString(1, pergunta.getMateria());
            stmt.setString(2, pergunta.getEnunciado());
            stmt.setString(3, pergunta.getAlternativaA());
            stmt.setString(4, pergunta.getAlternativaB());
            stmt.setString(5, pergunta.getAlternativaC());
            stmt.setString(6, pergunta.getAlternativaD());
            stmt.setString(7, String.valueOf(pergunta.getRespostaCorreta()));

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Pergunta cadastrada com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar pergunta.");
        }
    }

    public void removerPergunta(int id) throws Exception {
        String sql = "DELETE FROM perguntas WHERE id = ?";

        try (
            Connection conn = new ConnectionFactory().getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

