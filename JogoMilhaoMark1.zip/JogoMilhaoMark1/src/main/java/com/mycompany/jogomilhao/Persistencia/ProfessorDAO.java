
package com.mycompany.jogomilhao.Persistencia;

import com.mycompany.jogomilhao.TelaCadastro.Professor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfessorDAO {

    public void cadastrarProfessor(Professor professor) throws Exception {
        String sql = "INSERT INTO professores (nome, email, senha) VALUES (?, ?, ?)";

       try (
        Connection conn = new ConnectionFactory().getConnection();
        PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setString(1, professor.getNome());
            stmt.setString(2, professor.getEmail());
            stmt.setString(3, professor.getSenha());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao cadastrar professor", e);
        }

    } // <-- fechando o método cadastrarProfessor aqui

    public boolean validarLogin(String email, String senha) {
        String sql = "SELECT * FROM professores WHERE email = ? AND senha = ?";

        try (Connection conn = new ConnectionFactory().getConnection()) {
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, email);
        stmt.setString(2, senha);

        ResultSet rs = stmt.executeQuery();

        return rs.next(); // Retorna true se encontrou login
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }

    }
}
