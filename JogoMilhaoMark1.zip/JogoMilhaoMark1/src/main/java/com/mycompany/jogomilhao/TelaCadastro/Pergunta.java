package com.mycompany.jogomilhao.TelaCadastro;

public class Pergunta {
    private int id;
    private String materia;
    private String enunciado;
    private String a, b, c, d;
    private char respostaCorreta;

    public Pergunta(int id, String materia, String enunciado, String a, String b, String c, String d, char resposta) {
        this.id = id;
        this.materia = materia;
        this.enunciado = enunciado;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.respostaCorreta = resposta;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getMateria() {
        return materia;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public String getAlternativaA() {
        return a;
    }

    public String getAlternativaB() {
        return b;
    }

    public String getAlternativaC() {
        return c;
    }

    public String getAlternativaD() {
        return d;
    }

    public char getRespostaCorreta() {
        return respostaCorreta;
    }
}
