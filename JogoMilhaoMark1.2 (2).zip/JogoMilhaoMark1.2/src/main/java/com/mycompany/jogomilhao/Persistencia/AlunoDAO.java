package com.mycompany.jogomilhao.Persistencia;

import com.mycompany.jogomilhao.TelaCadastro.Aluno;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AlunoDAO {

    // Cadastra um novo aluno
    public void cadastrarAluno(Aluno aluno) throws Exception {
        String sql = "INSERT INTO aluno (nome, email, senha, id_turma) VALUES (?, ?, ?, ?)";

        try (
            Connection conn = new ConnectionFactory().getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getEmail());
            stmt.setDate(3, aluno.getSenha());
            stmt.setInt(4, aluno.getIdTurma());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao cadastrar aluno: " + e.getMessage(), e);
        }
    }

    // Validação de login usando e-mail e data de nascimento
    public boolean validarLoginPorData(String email, Date senha) throws Exception {
        String sql = "SELECT * FROM aluno WHERE email = ? AND senha = ?";

        try (
            Connection conn = new ConnectionFactory().getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setString(1, email);
            stmt.setDate(2, senha);

            ResultSet rs = stmt.executeQuery();
            return rs.next(); // true se encontrar

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao validar login: " + e.getMessage(), e);
        }
    }

    // Método não utilizado, pois usamos data como senha
    public boolean validarLogin(String email, String senha) {
        throw new UnsupportedOperationException("Método não implementado: login usa data de nascimento como senha.");
    }
}
