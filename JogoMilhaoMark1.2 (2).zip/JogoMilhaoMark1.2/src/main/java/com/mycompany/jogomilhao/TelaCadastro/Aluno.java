package com.mycompany.jogomilhao.TelaCadastro;

import java.sql.Date;

public class Aluno {
    private int id;
    private String nome;
    private String email;
    private Date senha; // senha como data de nascimento
    private int idTurma;

    // Construtor padrão
    public Aluno() {}

    // Construtor com todos os campos necessários
    public Aluno(String nome, String email, Date senha, int idTurma) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.idTurma = idTurma;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getSenha() {
        return senha;
    }

    public void setSenha(Date senha) {
        this.senha = senha;
    }

    public int getIdTurma() {
        return idTurma;
    }

    public void setIdTurma(int idTurma) {
        this.idTurma = idTurma;
    }
}
