package com.mycompany.jogomilhao.Persistencia;

import com.mycompany.jogomilhao.TelaCadastro.Materia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class MateriaDAO {

    public List<Materia> buscarTodasMaterias() {
        List<Materia> materias = new ArrayList<>();
        String sql = "SELECT id_materia, nome FROM materia ORDER BY nome";
        Connection conexao = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conexao = new ConnectionFactory().getConnection();
            stmt = conexao.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Materia materia = new Materia(
                    rs.getInt("id_materia"),
                    rs.getString("nome")
                );
                materias.add(materia);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar matérias: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conexao != null) conexao.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return materias;
    }

    public Materia buscarMateriaPorId(int idMateria) {
        Materia materia = null;
        String sql = "SELECT id_materia, nome FROM materia WHERE id_materia = ?";
        Connection conexao = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conexao = new ConnectionFactory().getConnection();
            stmt = conexao.prepareStatement(sql);
            stmt.setInt(1, idMateria);
            rs = stmt.executeQuery();

            if (rs.next()) {
                materia = new Materia(
                    rs.getInt("id_materia"),
                    rs.getString("nome")
                );
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar matéria: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conexao != null) conexao.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return materia;
    }
}
