package com.mycompany.jogomilhao.Persistencia;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
    private String host = "poliquest-bd-beatrizdesiqueiraf-fcca.f.aivencloud.com";
    private String port = "16248";
    private String db = "showdomilhao2";
    private String user = "avnadmin";
    private String password = "AVNS_pXX1DwkHT7cZ8lT_zEH";

    public Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver"); // Carrega o driver
        String url = String.format(
            "jdbc:mysql://%s:%s/%s?sslMode=REQUIRED", 
            host, port, db
        );
        return DriverManager.getConnection(url, user, password);
    }
}

/*package com.mycompany.jogomilhao.Persistencia;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

    private static final String URL = "jdbc:mysql://localhost:3306/showdomilhao2"; // Nome do seu banco
    private static final String USER = "root"; // seu usuário do MySQL
    private static final String PASSWORD = "imtdb"; // sua senha (se tiver)

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new RuntimeException("Erro na conexão com o banco de dados", e);
        }
    }
}
*/