
package com.mycompany.jogomilhao.TelaCadastro;

import java.time.LocalDateTime;

public class Ranking {
    private String nomeAluno;
    private String nomeTurma;
    private int pontuacao;
    private LocalDateTime dataHora;

    public Ranking(String nomeAluno, String nomeTurma, int pontuacao, LocalDateTime dataHora) {
        this.nomeAluno = nomeAluno;
        this.nomeTurma = nomeTurma;
        this.pontuacao = pontuacao;
        this.dataHora = dataHora;
    }

    public String getNomeAluno() {
        return nomeAluno;
    }

    public String getNomeTurma() {
        return nomeTurma;
    }

    public int getPontuacao() {
        return pontuacao;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }
}
