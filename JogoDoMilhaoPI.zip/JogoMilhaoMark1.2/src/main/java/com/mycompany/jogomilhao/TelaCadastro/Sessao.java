package com.mycompany.jogomilhao.TelaCadastro;

public class Sessao {
    public static int idAlunoLogado;
    public static String nomeAlunoLogado;

    public static void setAlunoLogado(int id, String nome) {
        idAlunoLogado = id;
        nomeAlunoLogado = nome;
    }

    public static void limparSessao() {
        idAlunoLogado = 0;
        nomeAlunoLogado = null;
    }
}
