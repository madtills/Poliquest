
package com.mycompany.jogomilhao.Persistencia;

import com.mycompany.jogomilhao.TelaCadastro.Ranking;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class RankingDAO {

    // Busca o ranking por turma
    public List<Ranking> buscarRankingPorTurma(String nomeTurma) throws Exception {
        List<Ranking> ranking = new ArrayList<>();

        String sql = """
            SELECT a.nome AS nome_aluno, t.nome AS nome_turma, r.pontuacao, r.data_hora
            FROM rodada r
            JOIN aluno a ON r.id_aluno = a.id_aluno
            JOIN turma t ON a.id_turma = t.id_turma
            WHERE t.nome = ?
            ORDER BY r.pontuacao DESC, r.data_hora ASC
        """;

        try (
            Connection conn = new ConnectionFactory().getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setString(1, nomeTurma);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Ranking r = new Ranking(
                    rs.getString("nome_aluno"),
                    rs.getString("nome_turma"),
                    rs.getInt("pontuacao"),
                    rs.getTimestamp("data_hora").toLocalDateTime()
                );
                ranking.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ranking;
    }

    // Salva a pontuação do aluno na tabela rodada
    public void salvarPontuacao(int idAluno, int pontuacao) throws Exception {
        String sql = "INSERT INTO rodada (id_aluno, pontuacao, data_hora) VALUES (?, ?, NOW())";

        try (
            Connection conn = new ConnectionFactory().getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)
        ) {
            stmt.setInt(1, idAluno);
            stmt.setInt(2, pontuacao);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new Exception("Erro ao salvar pontuação: " + e.getMessage());
        }
    }
}
