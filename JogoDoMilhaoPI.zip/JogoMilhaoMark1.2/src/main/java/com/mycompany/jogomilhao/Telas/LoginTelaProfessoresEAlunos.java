package com.mycompany.jogomilhao.Telas;

import com.mycompany.jogomilhao.ImagePanel;
import com.mycompany.jogomilhao.Telas.TelaInicialProfessor;
import com.mycompany.jogomilhao.Persistencia.AlunoDAO;
import com.mycompany.jogomilhao.Persistencia.ProfessorDAO;
import com.mycompany.jogomilhao.TelaCadastro.Aluno;
import com.mycompany.jogomilhao.TelaCadastro.Sessao;
import java.awt.BorderLayout;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class LoginTelaProfessoresEAlunos extends javax.swing.JFrame {

   
    public LoginTelaProfessoresEAlunos() {
        initComponents();
         ImagePanel imagePanel = new
        ImagePanel(getClass().getResource("/imagens/ImagemLogin.png"));
        this.setContentPane(imagePanel);
        this.setLayout(new BorderLayout());
        // Certifique-se de que todos os componentes são adicionados ao painel da imagem
        imagePanel.add(jPanel1);
        // Certifique-se de que a janela está corretamente dimensionada
        this.pack();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        campoEmail = new javax.swing.JTextField();
        campoSenha = new javax.swing.JTextField();
        BotaoCancelar = new javax.swing.JButton();
        BotaoLogin = new javax.swing.JButton();
        comboTipoUsuario = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setOpaque(false);

        BotaoCancelar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BotaoCancelar.setText("Cancelar");

        BotaoLogin.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BotaoLogin.setText("Entrar");
        BotaoLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotaoLoginActionPerformed(evt);
            }
        });

        comboTipoUsuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Professor", "Aluno" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 150, Short.MAX_VALUE)
                .addComponent(BotaoCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(BotaoLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(499, 499, 499))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(184, 184, 184)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(campoSenha, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
                            .addComponent(campoEmail)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(173, 173, 173)
                        .addComponent(comboTipoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(196, 196, 196)
                .addComponent(comboTipoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(campoEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(campoSenha, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotaoLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BotaoCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotaoLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotaoLoginActionPerformed
        // TODO add your handling code here:
       
        String email = campoEmail.getText();
        String senhaTexto = new String(campoSenha.getText()); // Para aluno, é a data
        String tipoUsuario = comboTipoUsuario.getSelectedItem().toString();

        if (email.isEmpty() || senhaTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha o email e a senha!");
            return;
        }

        if (tipoUsuario.equals("Professor")) {
            ProfessorDAO dao = new ProfessorDAO();
            boolean loginValido = dao.validarLogin(email, senhaTexto);

            if (loginValido) {
                JOptionPane.showMessageDialog(this, "Login como Professor realizado!");
                new TelaInicialProfessor().setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Email ou senha do professor incorretos!");
            }

        } else if (tipoUsuario.equals("Aluno")) {
            // Tenta converter a senha (data) para java.sql.Date
            java.sql.Date dataNascimento = null;
            try {
                java.util.Date utilDate = new SimpleDateFormat("dd-MM-yyyy").parse(senhaTexto);
                dataNascimento = new java.sql.Date(utilDate.getTime());
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(this, "Formato da data inválido! Use dd-MM-aaaa.");
                return;
            }

            AlunoDAO dao = new AlunoDAO();
            boolean loginValido = false;
            try {
                loginValido = dao.validarLoginPorData(email, dataNascimento);
            } catch (Exception ex) {
                Logger.getLogger(LoginTelaProfessoresEAlunos.class.getName()).log(Level.SEVERE, null, ex);
            }

            if (loginValido) {
                JOptionPane.showMessageDialog(this, "Login como Aluno realizado!");
                new TelaJogar7Ou6ANO().setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Email ou data de nascimento incorretos!");
            }
        }
       



    }//GEN-LAST:event_BotaoLoginActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginTelaProfessoresEAlunos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginTelaProfessoresEAlunos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginTelaProfessoresEAlunos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginTelaProfessoresEAlunos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginTelaProfessoresEAlunos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotaoCancelar;
    private javax.swing.JButton BotaoLogin;
    private javax.swing.JTextField campoEmail;
    private javax.swing.JTextField campoSenha;
    private javax.swing.JComboBox<String> comboTipoUsuario;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables

}