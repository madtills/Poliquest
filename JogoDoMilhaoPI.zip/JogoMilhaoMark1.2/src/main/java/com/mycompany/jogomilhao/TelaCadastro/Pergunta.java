package com.mycompany.jogomilhao.TelaCadastro;

public class Pergunta {
    private int id;
    private int idMateria;
    private String enunciado;
    private String alternativaA;
    private String alternativaB;
    private String alternativaC;
    private String alternativaD;
    private char respostaCorreta;
    private int anoEscolar;
    private String nivelDificuldade; // NOVO CAMPO

    // Construtor com ID (usado ao recuperar do banco)
    public Pergunta(int id, int idMateria, String enunciado, String alternativaA, String alternativaB,
                    String alternativaC, String alternativaD, char respostaCorreta, int anoEscolar, String nivelDificuldade) {
        this.id = id;
        this.idMateria = idMateria;
        this.enunciado = enunciado;
        this.alternativaA = alternativaA;
        this.alternativaB = alternativaB;
        this.alternativaC = alternativaC;
        this.alternativaD = alternativaD;
        this.respostaCorreta = respostaCorreta;
        this.anoEscolar = anoEscolar;
        this.nivelDificuldade = nivelDificuldade;
    }

    // Construtor sem ID (usado ao cadastrar nova pergunta)
    public Pergunta(int idMateria, String enunciado, String alternativaA, String alternativaB,
                    String alternativaC, String alternativaD, char respostaCorreta, int anoEscolar, String nivelDificuldade) {
        this.idMateria = idMateria;
        this.enunciado = enunciado;
        this.alternativaA = alternativaA;
        this.alternativaB = alternativaB;
        this.alternativaC = alternativaC;
        this.alternativaD = alternativaD;
        this.respostaCorreta = respostaCorreta;
        this.anoEscolar = anoEscolar;
        this.nivelDificuldade = nivelDificuldade;
    }

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdMateria() { return idMateria; }
    public void setIdMateria(int idMateria) { this.idMateria = idMateria; }

    public String getEnunciado() { return enunciado; }
    public void setEnunciado(String enunciado) { this.enunciado = enunciado; }

    public String getAlternativaA() { return alternativaA; }
    public void setAlternativaA(String alternativaA) { this.alternativaA = alternativaA; }

    public String getAlternativaB() { return alternativaB; }
    public void setAlternativaB(String alternativaB) { this.alternativaB = alternativaB; }

    public String getAlternativaC() { return alternativaC; }
    public void setAlternativaC(String alternativaC) { this.alternativaC = alternativaC; }

    public String getAlternativaD() { return alternativaD; }
    public void setAlternativaD(String alternativaD) { this.alternativaD = alternativaD; }

    public char getRespostaCorreta() { return respostaCorreta; }
    public void setRespostaCorreta(char respostaCorreta) { this.respostaCorreta = respostaCorreta; }

    public int getAnoEscolar() { return anoEscolar; }
    public void setAnoEscolar(int anoEscolar) { this.anoEscolar = anoEscolar; }

    public String getNivelDificuldade() { return nivelDificuldade; }
    public void setNivelDificuldade(String nivelDificuldade) { this.nivelDificuldade = nivelDificuldade; }
}

