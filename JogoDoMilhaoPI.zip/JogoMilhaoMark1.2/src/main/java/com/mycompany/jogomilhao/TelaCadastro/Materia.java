package com.mycompany.jogomilhao.TelaCadastro;

public class Materia {
    private int id;
    private String nome;

    // Construtor padrão (necessário se você usa frameworks ou serialização)
    public Materia() {
    }

    // Construtor com parâmetros
    public Materia(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // toString para exibir no ComboBox corretamente
    @Override
    public String toString() {
        return nome;
    }
}
