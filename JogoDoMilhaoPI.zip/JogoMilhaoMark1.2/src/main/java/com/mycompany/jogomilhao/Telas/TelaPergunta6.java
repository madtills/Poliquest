/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.jogomilhao.Telas;

import com.mycompany.jogomilhao.ImagePanel;
import com.mycompany.jogomilhao.Persistencia.PerguntaDAO;
import com.mycompany.jogomilhao.Persistencia.RankingDAO;
import com.mycompany.jogomilhao.TelaCadastro.Pergunta;
import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author Windows
 */
public class TelaPergunta6 extends javax.swing.JFrame {
    
// --- AQUI É ONDE VOCÊ INSERE O CÓDIGO ---
    private List<Pergunta> listaPerguntas; // Vai armazenar todas as perguntas do banco de dados
    private int perguntaAtual = 0; // Vai controlar qual pergunta está sendo exibida no momento
    private int pontos = 0;
    private int idAluno;
    
    private int dicasRestantes = 3;
    private int eliminacoesRestantes = 2;



    // ------------------------------------------
   

    
    
    /**
     * Creates new form TelaPergunta
     */
    public TelaPergunta6(String materia, int idAluno) {
    initComponents();
    this.idAluno = idAluno;
    
    lblPontos.setText("Pontuação: 0");  // ✅ Apenas atualiza o texto

    jPanel1.add(lblPontos); // Adiciona ao seu painel

    // --- AQUI É ONDE VOCÊ ADICIONA OS LISTENERS ---
    btnA.addActionListener(e -> verificarResposta('A'));
    btnB.addActionListener(e -> verificarResposta('B'));
    btnC.addActionListener(e -> verificarResposta('C'));
    btnD.addActionListener(e -> verificarResposta('D'));
    
    // ⬇️ AQUI! Adicione abaixo dos botões de resposta
    btnDicas.setText("Usar Dica (" + dicasRestantes + ")");
    btnEliminar.setText("Eliminar 2 alternativas (" + eliminacoesRestantes + ")");

    btnDicas.addActionListener(e -> usarDica());
    btnEliminar.addActionListener(e -> eliminarDuasAlternativas());

    // Mapeia a matéria para um idMateria (exemplo simples)
    int idMateria = 0;
    int ano = 6; // ano fixo ou que você desejar

    switch (materia.toLowerCase()) {
        case "matematica":
            idMateria = 1;
            break;
        case "portugues":
            idMateria = 2;
            break;
        case "geografia":
            idMateria = 3;
            break;
        case "historia":
            idMateria = 4;
            break;
        case "ciencias":
            idMateria = 5;
            break;
        default:
            JOptionPane.showMessageDialog(this, "Matéria inválida: " + materia);
            this.dispose();
            return;
    }

    carregarPerguntas(idMateria, ano);

    ImagePanel imagePanel = new ImagePanel(getClass().getResource("/imagens/TelaPerguntasCerta.png"));
    this.setContentPane(imagePanel);
    this.setLayout(new BorderLayout());
    imagePanel.add(jPanel1);
    this.pack();
}


    
    // AQUI É ONDE VOCÊ INSERE O CÓDIGO DO MÉTODO carregarPerguntas()
    private void carregarPerguntas(int idMateria, int ano) {
    this.listaPerguntas = new ArrayList<>();
    this.perguntaAtual = 0;

    PerguntaDAO dao = new PerguntaDAO();

    try {
        // Busca perguntas separadas por nível
        List<Pergunta> faceis = dao.buscarPerguntasPorMateriaENivel(idMateria, ano, "facil");
        List<Pergunta> medias = dao.buscarPerguntasPorMateriaENivel(idMateria, ano, "media");
        List<Pergunta> dificies = dao.buscarPerguntasPorMateriaENivel(idMateria, ano, "dificil");

        // Embaralha dentro de cada nível
        Collections.shuffle(faceis);
        Collections.shuffle(medias);
        Collections.shuffle(dificies);

        // Junta todas na ordem certa
        listaPerguntas.addAll(faceis);
        listaPerguntas.addAll(medias);
        listaPerguntas.addAll(dificies);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Erro ao carregar perguntas: " + e.getMessage(), "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
        this.dispose();
        return;
    }

    if (listaPerguntas.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Nenhuma pergunta encontrada para a matéria selecionada.");
    } else {
        mostrarPergunta();
    }
}

    // ---------------------------------------------------------------
    
// --- AQUI É ONDE VOCÊ INSERE O CÓDIGO DO MÉTODO mostrarPergunta() ---
    private void mostrarPergunta() {
        if (perguntaAtual < listaPerguntas.size()) {
            Pergunta p = listaPerguntas.get(perguntaAtual);
            // Certifique-se de que esses componentes (lblEnunciado, btnA, etc.) existem na sua tela
            // e que os nomes estão corretos (lblEnunciado, btnA, btnB, btnC, btnD).
            lblEnunciado.setText(p.getEnunciado());
            btnA.setText("A) " + p.getAlternativaA());
            btnB.setText("B) " + p.getAlternativaB());
            btnC.setText("C) " + p.getAlternativaC());
            btnD.setText("D) " + p.getAlternativaD());
        } else {
            // Fim das perguntas
            JOptionPane.showMessageDialog(this, "Você Terminou!");
            this.dispose(); // Fecha a janela da tela do jogo
            atualizarPontuacao();

        }
        btnA.setEnabled(true);
        btnB.setEnabled(true);
        btnC.setEnabled(true);
        btnD.setEnabled(true);

    }
    
        private void atualizarPontuacao() {
            lblPontos.setText("Pontuação: " + pontos);
        }

    
        private void verificarResposta(char letra) {
            Pergunta p = listaPerguntas.get(perguntaAtual);

            // Confirmação da resposta
            int confirmar = JOptionPane.showConfirmDialog(this, 
                "Tem certeza que deseja escolher a alternativa " + letra + "?", 
                "Confirmar Resposta", 
                JOptionPane.YES_NO_OPTION);

            if (confirmar != JOptionPane.YES_OPTION) {
                return; // Usuário desistiu de responder
            }

            // Verificação da resposta
            if (p.getRespostaCorreta() == letra) {
                pontos += 100; // Incrementa 100 pontos por acerto
                atualizarPontuacao();
                System.out.println("Pontuação atual: " + pontos);  // Verifique no console se a pontuação está mudando


                JOptionPane.showMessageDialog(this, 
                    "✅ Resposta correta!\nPontuação atual: " + pontos);
            } else {
                try {
                    new RankingDAO().salvarPontuacao(idAluno, pontos);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Erro ao salvar pontuação: " + ex.getMessage());
                }

                JOptionPane.showMessageDialog(this, 
                    "❌ Resposta errada!\nA resposta correta era: " + p.getRespostaCorreta() + 
                    "\nPontuação final: " + pontos);
                this.dispose();
                return;
            }

            // Avança para a próxima pergunta apenas se o jogador quiser
            perguntaAtual++;
            int continuar = JOptionPane.showConfirmDialog(this,
                "Deseja continuar para a próxima pergunta?",
                "Continuar?",
                JOptionPane.YES_NO_OPTION);

            // Dentro de verificarResposta() no trecho:
        if (continuar == JOptionPane.YES_OPTION) {
            mostrarPergunta();
        } else {
            try {
                new RankingDAO().salvarPontuacao(idAluno, pontos);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erro ao salvar pontuação: " + ex.getMessage());
            }

            JOptionPane.showMessageDialog(this, 
                "Jogo encerrado.\nPontuação final: " + pontos);
            this.dispose();
        }

        }
        private void usarDica() {
            if (dicasRestantes <= 0) {
                JOptionPane.showMessageDialog(this, "Você já usou todas as dicas!");
                return;
            }

            Pergunta p = listaPerguntas.get(perguntaAtual);
            char correta = p.getRespostaCorreta();

            char sugestao;
            double chance = Math.random();

            if (chance <= 0.7) {
                sugestao = correta;
            } else {
                List<Character> alternativas = List.of('A', 'B', 'C', 'D');
                List<Character> erradas = new ArrayList<>(alternativas);
                erradas.remove(Character.valueOf(correta));
                sugestao = erradas.get((int)(Math.random() * erradas.size()));
            }

            JOptionPane.showMessageDialog(this,
                "🤖 Dica: A alternativa que parece mais correta é a letra **" + sugestao + "**.");

            dicasRestantes--;
            btnDicas.setText("Usar Dica (" + dicasRestantes + ")");
            if (dicasRestantes == 0) {
                btnDicas.setEnabled(false);
            }
        }
        
        private void eliminarDuasAlternativas() {
            if (eliminacoesRestantes <= 0) {
                JOptionPane.showMessageDialog(this, "Você já usou todas as eliminações!");
                return;
            }

            Pergunta p = listaPerguntas.get(perguntaAtual);
            char correta = p.getRespostaCorreta();

            List<JButton> botoes = List.of(btnA, btnB, btnC, btnD);
            List<Character> letras = List.of('A', 'B', 'C', 'D');

            List<JButton> errados = new ArrayList<>();
            for (int i = 0; i < botoes.size(); i++) {
                if (letras.get(i) != correta) {
                    errados.add(botoes.get(i));
                }
            }

            Collections.shuffle(errados);
            errados.get(0).setEnabled(false);
            errados.get(1).setEnabled(false);

            eliminacoesRestantes--;
            btnEliminar.setText("Eliminar 2 alternativas (" + eliminacoesRestantes + ")");
            if (eliminacoesRestantes == 0) {
                btnEliminar.setEnabled(false);
            }
        }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblEnunciado = new javax.swing.JLabel();
        btnA = new javax.swing.JButton();
        btnB = new javax.swing.JButton();
        btnC = new javax.swing.JButton();
        btnD = new javax.swing.JButton();
        lblPontos = new javax.swing.JLabel();
        btnDicas = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setOpaque(false);

        lblEnunciado.setBackground(new java.awt.Color(255, 255, 255));
        lblEnunciado.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblEnunciado.setForeground(new java.awt.Color(0, 0, 0));
        lblEnunciado.setText("jLabel1");
        lblEnunciado.setOpaque(true);

        btnA.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnA.setText("A");
        btnA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAActionPerformed(evt);
            }
        });

        btnB.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnB.setText("B");
        btnB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBActionPerformed(evt);
            }
        });

        btnC.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnC.setText("C");
        btnC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCActionPerformed(evt);
            }
        });

        btnD.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnD.setText("D");
        btnD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDActionPerformed(evt);
            }
        });

        lblPontos.setBackground(new java.awt.Color(255, 255, 255));
        lblPontos.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblPontos.setForeground(new java.awt.Color(255, 255, 255));
        lblPontos.setText("Pontuação: 0");

        btnDicas.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnDicas.setText("Dicas");

        btnEliminar.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnEliminar.setText("50/50");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblEnunciado, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(lblPontos, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnDicas, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE))
                        .addComponent(btnD, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnB, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnA, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnC, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(39, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblPontos, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 69, Short.MAX_VALUE))
                    .addComponent(lblEnunciado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(btnA, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnB, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnC, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnD, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDicas, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDActionPerformed
        // TODO add your handling code here:
         verificarResposta('D');
    }//GEN-LAST:event_btnDActionPerformed

    private void btnAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAActionPerformed
        // TODO add your handling code here:
         verificarResposta('A');
    }//GEN-LAST:event_btnAActionPerformed

    private void btnCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCActionPerformed
        // TODO add your handling code here:
         verificarResposta('C');
    }//GEN-LAST:event_btnCActionPerformed

    private void btnBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBActionPerformed
        // TODO add your handling code here:
         verificarResposta('B');
    }//GEN-LAST:event_btnBActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnA;
    private javax.swing.JButton btnB;
    private javax.swing.JButton btnC;
    private javax.swing.JButton btnD;
    private javax.swing.JButton btnDicas;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblEnunciado;
    private javax.swing.JLabel lblPontos;
    // End of variables declaration//GEN-END:variables

    

}
