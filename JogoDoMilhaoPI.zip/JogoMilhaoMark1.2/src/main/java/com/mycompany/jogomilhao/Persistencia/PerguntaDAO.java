package com.mycompany.jogomilhao.Persistencia;

import com.mycompany.jogomilhao.TelaCadastro.Pergunta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class PerguntaDAO {

    public void adicionarPergunta(Pergunta pergunta) {
        String sql = "INSERT INTO questao (id_materia, enunciado, opcao_a, opcao_b, " +
                     "opcao_c, opcao_d, opcao_correta, ano_escolar, dificuldade) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = new ConnectionFactory().getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, pergunta.getIdMateria());
            stmt.setString(2, pergunta.getEnunciado());
            stmt.setString(3, pergunta.getAlternativaA());
            stmt.setString(4, pergunta.getAlternativaB());
            stmt.setString(5, pergunta.getAlternativaC());
            stmt.setString(6, pergunta.getAlternativaD());
            stmt.setString(7, String.valueOf(pergunta.getRespostaCorreta()));
            stmt.setInt(8, pergunta.getAnoEscolar());
            stmt.setString(9, pergunta.getNivelDificuldade());

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Pergunta cadastrada com sucesso!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar pergunta: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public List<Pergunta> buscarPerguntasPorMateria(int idMateria, int ano) {
        List<Pergunta> perguntas = new ArrayList<>();
        String sql = "SELECT * FROM questao WHERE id_materia = ? AND ano_escolar = ?";

        try (Connection conexao = new ConnectionFactory().getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idMateria);
            stmt.setInt(2, ano);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Pergunta pergunta = new Pergunta(
                        rs.getInt("id_questao"),
                        rs.getInt("id_materia"),
                        rs.getString("enunciado"),
                        rs.getString("opcao_a"),
                        rs.getString("opcao_b"),
                        rs.getString("opcao_c"),
                        rs.getString("opcao_d"),
                        rs.getString("opcao_correta").charAt(0),
                        rs.getInt("ano_escolar"),
                        rs.getString("dificuldade")
                    );
                    perguntas.add(pergunta);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar perguntas: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        return perguntas;
    }

    // ✅ NOVO MÉTODO para buscar por dificuldade
    public List<Pergunta> buscarPerguntasPorMateriaENivel(int idMateria, int ano, String nivelDificuldade) {
        List<Pergunta> perguntas = new ArrayList<>();
        String sql = "SELECT * FROM questao WHERE id_materia = ? AND ano_escolar = ? AND dificuldade = ?";

        try (Connection conexao = new ConnectionFactory().getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idMateria);
            stmt.setInt(2, ano);
            stmt.setString(3, nivelDificuldade);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Pergunta pergunta = new Pergunta(
                        rs.getInt("id_questao"),
                        rs.getInt("id_materia"),
                        rs.getString("enunciado"),
                        rs.getString("opcao_a"),
                        rs.getString("opcao_b"),
                        rs.getString("opcao_c"),
                        rs.getString("opcao_d"),
                        rs.getString("opcao_correta").charAt(0),
                        rs.getInt("ano_escolar"),
                        rs.getString("dificuldade")
                    );
                    perguntas.add(pergunta);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar perguntas por dificuldade: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        return perguntas;
    }

    public boolean removerPerguntaPorId(int idPergunta) throws Exception {
        String sql = "DELETE FROM questao WHERE id_questao = ?";
        boolean sucesso = false;

        try (Connection conexao = new ConnectionFactory().getConnection();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idPergunta);
            int linhasAfetadas = stmt.executeUpdate();

            sucesso = linhasAfetadas > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return sucesso;
    }
}
