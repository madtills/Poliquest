package com.mycompany.jogomilhao.Telas; // Ou o pacote correto da sua TelaCadastroPergunta

import com.mycompany.jogomilhao.Persistencia.MateriaDAO;
import com.mycompany.jogomilhao.Persistencia.PerguntaDAO;
import com.mycompany.jogomilhao.TelaCadastro.Materia;
import com.mycompany.jogomilhao.TelaCadastro.Pergunta; // VERIFIQUE ESTE IMPORT!
                                                      // Se sua classe Pergunta está em com.mycompany.jogomilhao.Model,
                                                      // troque para: import com.mycompany.jogomilhao.Model.Pergunta;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent; // Para o listener de ação
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.DefaultComboBoxModel; // Para usar DefaultComboBoxModel

public class TelaCadastroPergunta extends javax.swing.JFrame { // ou JPanel, dependendo da sua arquitetura

    
    private List<Materia> listaMaterias = new ArrayList<>();
    private Map<String, Materia> materiaMap = new HashMap<>();

    /**
     * Construtor da TelaCadastroPergunta
     */
    public TelaCadastroPergunta() {
        initComponents();
        // Inicializar os JComboBox, se não forem preenchidos no designer
        preencherComboBox();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtC = new javax.swing.JTextField();
        txtD = new javax.swing.JTextField();
        txtEnunciado = new javax.swing.JTextField();
        txtResposta = new javax.swing.JTextField();
        txtA = new javax.swing.JTextField();
        btnAdicionar = new javax.swing.JButton();
        jButtonRemover = new javax.swing.JButton();
        txtB = new javax.swing.JTextField();
        comboAno = new javax.swing.JComboBox<>();
        ComboMateria = new javax.swing.JComboBox<>();
        txtIdRemover = new javax.swing.JTextField();
        comboDificuldade = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setOpaque(false);

        txtC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCActionPerformed(evt);
            }
        });

        btnAdicionar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnAdicionar.setText("Adicionar");
        btnAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarActionPerformed(evt);
            }
        });

        jButtonRemover.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButtonRemover.setText("Remover");
        jButtonRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoverActionPerformed(evt);
            }
        });

        comboAno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "6 Ano", "7 Ano" }));

        ComboMateria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mátematica", "Português", "Geografia", "História", "Ciências" }));

        txtIdRemover.setText("jTextField1");

        comboDificuldade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fácil", "Média", "Difícil" }));
        comboDificuldade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboDificuldadeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 168, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(comboDificuldade, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtIdRemover, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 626, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(ComboMateria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(comboAno, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(txtA, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(56, 56, 56))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(btnAdicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(36, 36, 36)))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jButtonRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtC, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtD, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(36, 36, 36)
                            .addComponent(txtResposta, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(37, 37, 37))
                        .addComponent(txtEnunciado)
                        .addComponent(txtB, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(181, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(comboAno, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(comboDificuldade, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ComboMateria, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(txtEnunciado, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(txtResposta, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtC, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtA, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtB, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)
                            .addComponent(txtD))
                        .addGap(65, 65, 65)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAdicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29)))
                .addComponent(txtIdRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarActionPerformed
        try {
            String nomeMateriaSelecionada = (String) ComboMateria.getSelectedItem();
            Materia materiaSelecionada = materiaMap.get(nomeMateriaSelecionada);

            if (materiaSelecionada == null || materiaSelecionada.getId() == -1) {
                JOptionPane.showMessageDialog(this, "Selecione uma matéria válida.");
                return;
            }

            // Captura da dificuldade
            String dificuldade = (String) comboDificuldade.getSelectedItem();
            if (dificuldade == null || dificuldade.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Selecione uma dificuldade.");
                return;
            }

            String enunciado = txtEnunciado.getText();
            String a = txtA.getText();
            String b = txtB.getText();
            String c = txtC.getText();
            String d = txtD.getText();
            String resposta = txtResposta.getText().toUpperCase();

            // Validação consolidada
            if (comboAno.getSelectedIndex() == 0 || resposta.isEmpty() || enunciado.isEmpty()
                    || a.isEmpty() || b.isEmpty() || c.isEmpty() || d.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Preencha todos os campos.");
                return;
            }

            if (!resposta.matches("[ABCD]")) {
                JOptionPane.showMessageDialog(this, "A resposta deve ser A, B, C ou D.");
                return;
            }

            int ano = Integer.parseInt(comboAno.getSelectedItem().toString().split(" ")[0]);

            Pergunta pergunta = new Pergunta(
                    0, // ID será gerado
                    materiaSelecionada.getId(),
                    enunciado,
                    a, b, c, d,
                    resposta.charAt(0),
                    ano,
                    dificuldade // <--- novo campo adicionado aqui
            );

            PerguntaDAO dao = new PerguntaDAO();
            dao.adicionarPergunta(pergunta); // método precisa aceitar a dificuldade também

            JOptionPane.showMessageDialog(this, "Pergunta adicionada com sucesso!");
            limparCampos();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "O ano deve ser um número válido.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao adicionar pergunta: " + e.getMessage());
        }

    }//GEN-LAST:event_btnAdicionarActionPerformed

    private void txtCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCActionPerformed

    private void jButtonRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoverActionPerformed
       try {
        String idTexto = txtIdRemover.getText().trim();
        if (idTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o ID da pergunta a remover.");
            return;
        }

        int id = Integer.parseInt(idTexto);

        PerguntaDAO dao = new PerguntaDAO();
        // CHAMA O MÉTODO COM O NOME CORRETO (removerPerguntaPorId)
        boolean sucesso = dao.removerPerguntaPorId(id);

        if (sucesso) {
            JOptionPane.showMessageDialog(this, "Pergunta removida com sucesso!");
            txtIdRemover.setText(""); // Limpa apenas o campo de ID após sucesso
        } else {
            JOptionPane.showMessageDialog(this, "Pergunta com ID informado não encontrada.");
        }

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "O ID deve ser um número válido.");
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Erro ao remover pergunta: " + e.getMessage());
    }
    }//GEN-LAST:event_jButtonRemoverActionPerformed

    private void comboDificuldadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboDificuldadeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboDificuldadeActionPerformed
    
   // Método atualizado:
    private void preencherComboBox() {
        ComboMateria.removeAllItems();
        ComboMateria.addItem("Selecione a Matéria");
        materiaMap.clear();

        MateriaDAO materiaDAO = new MateriaDAO();
        listaMaterias = materiaDAO.buscarTodasMaterias();

        for (Materia m : listaMaterias) {
            ComboMateria.addItem(m.getNome());
            materiaMap.put(m.getNome(), m); // associa o nome ao objeto
        }

        ComboMateria.setSelectedIndex(0);

        comboAno.removeAllItems();
        comboAno.addItem("Selecione o Ano");
        comboAno.addItem("6 Ano");
        comboAno.addItem("7 Ano");
        comboAno.setSelectedIndex(0);
    }



    private void limparCampos() {
    // COLE O CONTEÚDO AQUI:
    txtEnunciado.setText("");
    txtA.setText("");
    txtB.setText("");
    txtC.setText("");
    txtD.setText("");
    txtResposta.setText("");

    // Esta linha é condicional: só execute se 'txtIdRemover' realmente existir na sua tela
    if (txtIdRemover != null) { // Adicione esta verificação se não tiver certeza
        txtIdRemover.setText("");
    }

    ComboMateria.setSelectedIndex(0);
    comboAno.setSelectedIndex(0);
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroPergunta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroPergunta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroPergunta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCadastroPergunta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCadastroPergunta().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboMateria;
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JComboBox<String> comboAno;
    private javax.swing.JComboBox<String> comboDificuldade;
    private javax.swing.JButton jButtonRemover;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtA;
    private javax.swing.JTextField txtB;
    private javax.swing.JTextField txtC;
    private javax.swing.JTextField txtD;
    private javax.swing.JTextField txtEnunciado;
    private javax.swing.JTextField txtIdRemover;
    private javax.swing.JTextField txtResposta;
    // End of variables declaration//GEN-END:variables
}
